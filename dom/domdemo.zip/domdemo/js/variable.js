// 页面中form表单的item项目数
let count = 1;

// 表单数据
let data = [];
// 临时存放表单数据的某一项
let temp = {};

// 表单节点
const form = document.querySelector('.question');
// 存放表单数据的节点
const form_data = document.querySelector('.form-data')
