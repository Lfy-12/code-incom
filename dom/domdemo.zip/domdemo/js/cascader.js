// 多级下拉
const multiSelect_template = `
    <span class='right-icon'>
    <img class="delete" src='img/delete.png'/>
    <img class="move" src='img/move.png'/>
    </span>
    <div class="title">
    <input type="text" class="textInput" value="请选择以下选项"/>
    </div>
    <div class="cascader_box">
    <select class="cascader_item">
        <option>请选择</option>
        <option>选项1</option>
    </select>
    <select class="cascader_item">
        <option>请选择</option>
        <option>选项1-1</option>
    </select>
    </div>
    <div class="btn-box">
    <button class="edit-option-list">编辑选项</button>
    <button>导入选项</button>
    </div>
    <div class="add-cascader-choose">
        <div class="add-header">
        <span>编辑选项</sp>
        <img class="close" src="img/close.png" alt="" srcset="">
        </div>
        <div class="add-content">
            <div class="cascader" index="1">
                <div class="cascader-header">
                    一级选项
                </div>
                <div class="cascader-list">
                    <input type="text" value="请选择">
                    <input type="text" value="选项1">
                </div>
                <button class="add-cascader">+添加按钮</button>
            </div>
            <div class="cascader" index="2">
                <div class="cascader-header">
                    二级选项
                </div>
            </div>
            <div class="cascader" index="3">
                <div class="cascader-header">
                    三级选项
                </div>
            </div>
            <div class="cascader" index="4">
                <div class="cascader-header">
                    四级选项
                </div>
            </div>
        </div>
    </div>`
function multiSelect(){
    let countSpan = `<span class='count'>${count}</span>`;
    let multiSelect_html = countSpan + multiSelect_template;
    const item = document.createElement('div');
    item.innerHTML = multiSelect_html;
    common(item);

    const btn = item.querySelector('.edit-option-list');
    const addBox = item.querySelector('.add-cascader-choose');
    const bg = document.querySelector('.bg');
    const close = item.querySelector('.close');
    btn.addEventListener('click',function(){
        addBox.style.display = 'block';
        bg.style.display = 'block';
    })
    close.addEventListener('click',function(){
        addBox.style.display = 'none';
        bg.style.display = 'none';
    })
}